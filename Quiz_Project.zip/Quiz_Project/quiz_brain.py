class QuizBrain:

    def __init__(self, bank):
        self.question_number = 0
        self.questions_list = bank
        self.score = 0

    def next_question(self):
        current_question = self.questions_list[self.question_number]
        self.question_number += 1

        answer = input(f"Q{self.question_number}: {current_question.text} (True/False):\n")
        if answer.lower() == current_question.answer.lower():
            print("Congratulations! You answered that question correctly")
            self.score += 1

        else:
            print("Incorrect.")

    def still_has_questions(self):
         if self.question_number < len(self.questions_list):
            return True
         else:
            return False

    def results(self):
        print(f"The Quiz is now over. You scored {self.score} out of {len(self.questions_list)} ")
