from data import MENU
from data import resources


def make_drink(drink_choice, money):
    drink_ingredients = MENU[drink_choice]["ingredients"]
    drink_cost = MENU[drink_choice]["cost"]
    ingredient_check = True
    change = 0

    for value in drink_ingredients:
        if drink_ingredients[value] > resources[value]:
            ingredient_check = False

        else:
            resources[value] -= drink_ingredients[value]

    if ingredient_check:
        if money < drink_cost:
            print(f"You have not inserted enough money for a {drink_choice}")
        else:
            change = money - drink_cost
            print(f"Here is your {drink_choice} and here is your change of,  ${change}")
    else:
        print(f"The machine does not have the required ingredients, check {list(resources.keys())} levels")



coin_total = 0
drink_flag = True
while drink_flag:
    choice = input("What would you like to order? (espresso/latte/cappuccino)\n")
    print("Please insert coins:")
    quarters = int(input("How many quarters?:\n"))
    dimes = int(input("How many dimes?:\n"))
    nickels = int(input("How many nickels?:\n"))
    pennies = int(input("How many pennies?:\n"))
    coin_total = (quarters*0.25) + (dimes*0.10) + (nickels*0.05) + (pennies*0.01)

    if choice == "espresso" or "latte" or "cappuccino":
        make_drink(choice, coin_total)
    else:
        print(resources)
        print(f"${money}")
    continue_drink = input("If you would like to order again, type 'y', otherwise, type 'n'.\n")
    if continue_drink != 'y':
        drink_flag = False