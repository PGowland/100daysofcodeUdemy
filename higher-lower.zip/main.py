import random
import os
from art import logo
from art import vs
print(logo)
from game_data import data
streak = True
score = 0
play_again = True
while play_again:
  while streak:
    random_a = data[(random.randrange(0, len(data)))]
    random_b = data[(random.randrange(0, len(data)))]
  
    while random_a == random_b:
      random_b = data[(random.randrange(0, len(data)+1))]
  
    print(f"Compare A: {random_a['name']}, {random_a['description']}, from {random_a['country']}")
    print(vs)
    print(f"Against B: {random_b['name']}, {random_b['description']}, from {random_b['country']}")
    guess = input("Who has more followers, A or B?\n")
    if guess == 'A' and random_a['follower_count'] > random_b['follower_count']:
      
      os.system('clear')
      print("You are Correct\n")
      score += 1
      print(f"You've answered {score} in a row\n")
      
    elif guess == 'B' and random_a['follower_count'] < random_b['follower_count']:
      os.system('clear')
      print("You are Correct\n")
      score += 1
      print(f"You've answered {score} in a row\n")
      
    else:
      os.system('clear')
      print("Incorrect")
      print(f"You're answer streak was {score}")
      break
    
  play_again = input("Would you like to play again? type 'Yes' or 'No'")
  if play_again == "Yes":
     os.system('clear')
     score = 0
     play_again = True
  else:
    play_again = False
   

 