from art import logo
print(logo)
def add(n1, n2):
  return n1 + n2

def subtract(n1, n2):
  return n1 - n2

def multiply(n1, n2):
  return n1 * n2

def divide(n1, n2):
  return n1/n2

operations = {
  "+" : add,
  "-" : subtract, 
  "*" : multiply, 
  "/" : divide, 
}

def calculator():
  first_number = float(input("Please enter the first number of your calculation\n"))
  another_calc = True
  for symbol in operations:
      print(symbol)
  while another_calc:
  
    op_symbol = input("Pick an operation.\n")
    second_number = float(input("Please enter the next number of your calculation\n"))
    function = operations[op_symbol]
    answer = function(first_number, second_number)
  
    print(f"{first_number} {op_symbol} {second_number} = {answer}")
  
    y_or_n = input(f"Type 'y' to continue calculating with {answer},'n' to start over, and 'exit' to leave the calculator\n")
    if y_or_n == "y":
      first_number = answer
    elif y_or_n == "exit":
      break
    else:
      another_calc = False
      calculator()

calculator()
    
 
   
