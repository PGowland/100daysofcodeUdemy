import turtle


class Movements:

    def __init__(self):
        self.turtle = turtle.Turtle()

    def fd_key(self):
        self.turtle.fd(10)

    def bk_key(self):
        self.turtle.bk(10)

    def left_key(self):
        self.turtle.right(10)

    def right_key(self):
        self.turtle.left(10)

    def clearscreen(self):
        self.turtle.home()
        self.turtle.clear()




