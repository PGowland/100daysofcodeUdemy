import turtle
from turtle import Turtle, Screen
from movements import Movements

screen = Screen()
timmy = Turtle()
movements = Movements()

turtle.seth(turtle.heading() + 50)

screen.listen()
screen.onkey(movements.fd_key, "w")
screen.onkey(movements.bk_key, "s")
screen.onkey(movements.left_key, "a")
screen.onkey(movements.right_key, "d")
screen.onkey(movements.clearscreen, "space")


screen.exitonclick()
